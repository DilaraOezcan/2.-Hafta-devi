public class Samurai extends MyCharacter {
    public Samurai() {
        super(1,"Samurai",5, 21, 15);
    }
}
