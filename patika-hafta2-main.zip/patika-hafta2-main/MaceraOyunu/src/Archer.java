public class Archer extends MyCharacter {
    public Archer() {
        super(2,"Archer",7, 18, 20);
    }
}
