public class Vampire extends Obstacle{
    public Vampire() {
        super(2, "Vampire",4,14,7);
    }
}
