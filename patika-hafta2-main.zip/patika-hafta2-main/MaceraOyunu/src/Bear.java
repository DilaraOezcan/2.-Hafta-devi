public class Bear extends Obstacle{
    public Bear() {
        super(4, "Bear",7,20,12);
    }
}
