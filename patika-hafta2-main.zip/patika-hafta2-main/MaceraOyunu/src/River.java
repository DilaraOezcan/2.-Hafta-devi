public class River extends BattleLoc{
    public River(Player player) {
        super("Nehir", player, new Bear(), "water",2);
    }
}
