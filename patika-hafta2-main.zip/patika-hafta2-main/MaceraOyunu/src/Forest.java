public class Forest extends  BattleLoc{
    public Forest(Player player) {
        super("Orman", player,new Vampire(), "Firewood",3);
    }
}
