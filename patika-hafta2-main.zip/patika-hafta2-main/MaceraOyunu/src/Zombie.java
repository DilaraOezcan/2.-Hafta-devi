public class Zombie extends Obstacle{

    public Zombie() {
        super(1, "Zombie", 3,10,4);
    }
}
