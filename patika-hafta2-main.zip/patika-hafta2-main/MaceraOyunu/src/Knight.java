public class Knight extends MyCharacter {
    public Knight() {
        super(3,"Knight",8, 24, 5);
    }
}
